import React from 'react';
import Hero from '../components/home/Hero';
import Services from '../components/home/Services';
import HowItWorks from '../components/home/HowItWorks';
import Testimonials from '../components/home/Testimonials';
import AppPromo from '../components/home/AppPromo';
import FAQSection from '../components/home/FAQSection';
import OnlineDrivers from '../components/drivers/OnlineDrivers';

const HomePage: React.FC = () => {
  return (
    <div>
      <Hero />
      <OnlineDrivers />
      <Services />
      <HowItWorks />
      <Testimonials />
      <AppPromo />
      <FAQSection />
    </div>
  );
};

export default HomePage;