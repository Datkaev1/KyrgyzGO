import React from 'react';
import { Apple, Phone } from 'lucide-react';

const AppPromo: React.FC = () => {
  return (
    <section className="py-20 bg-gradient-to-r from-red-600 to-red-800 text-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              KyrgyzGo мобилдик тиркемесин жүктөп алыңыз
            </h2>
            <p className="text-xl mb-8 text-red-100">
              Бир кнопка менен такси чакыруу, жол акысын алдын ала билүү, аткарылган сапарларды көзөмөлдөө 
              жана башка мүмкүнчүлүктөрдөн пайдаланыңыз.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <a 
                href="#" 
                className="flex items-center bg-black hover:bg-gray-900 text-white px-6 py-3 rounded-lg transition-colors"
              >
                <Apple size={24} className="mr-3" />
                <div>
                  <div className="text-xs">App Store'дон жүктөңүз</div>
                  <div className="font-semibold">iPhone үчүн</div>
                </div>
              </a>
              
              <a 
                href="#" 
                className="flex items-center bg-black hover:bg-gray-900 text-white px-6 py-3 rounded-lg transition-colors"
              >
                <Phone size={24} className="mr-3" />
                <div>
                  <div className="text-xs">Google Play'ден жүктөңүз</div>
                  <div className="font-semibold">Android үчүн</div>
                </div>
              </a>
            </div>
          </div>
          
          <div className="flex justify-center md:justify-end">
            <div className="relative w-64 h-[500px]">
              <div className="absolute inset-0 bg-black rounded-3xl overflow-hidden shadow-2xl transform rotate-3">
                {/* Placeholder for mobile app screenshot */}
                <div className="w-full h-full bg-gray-800 flex items-center justify-center text-center p-6">
                  <div>
                    <span className="text-2xl font-bold text-red-500">KyrgyzGo</span>
                    <p className="mt-4 text-gray-300">Мобилдик тиркеменин демо версиясы</p>
                  </div>
                </div>
              </div>
              <div className="absolute inset-0 bg-black rounded-3xl overflow-hidden shadow-2xl transform -rotate-3">
                {/* Placeholder for mobile app screenshot */}
                <div className="w-full h-full bg-gray-800 flex items-center justify-center text-center p-6">
                  <div>
                    <span className="text-2xl font-bold text-red-500">KyrgyzGo</span>
                    <p className="mt-4 text-gray-300">Мобилдик тиркеменин демо версиясы</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AppPromo;