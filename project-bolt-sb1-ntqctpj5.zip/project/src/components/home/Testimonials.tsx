import React from 'react';
import { Star } from 'lucide-react';

const Testimonials: React.FC = () => {
  const testimonials = [
    {
      id: 1,
      name: 'Азамат Асанов',
      avatar: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=100',
      rating: 5,
      text: 'Мен KyrgyzGo кызматын үзгүлтүксүз колдоном. Унаалар дайыма таза, айдоочулар сылык жана кесипкөй. Тапшырманы берген соң, унаа 5-10 мүнөттүн ичинде келет.',
      date: '15.06.2024'
    },
    {
      id: 2,
      name: 'Айгүл Исакова',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100',
      rating: 5,
      text: 'Бишкекке келген сайын KyrgyzGo кызматын колдоном. Баалары жеткиликтүү, айдоочулар кесипкөй. Мобилдик тиркеме абдан ыңгайлуу колдонулат, сунуштайм!',
      date: '02.07.2024'
    },
    {
      id: 3,
      name: 'Нурлан Жумабеков',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100',
      rating: 4,
      text: 'Жакшы кызмат көрсөтүү, бирок кээде күтүү убактысы узак болот. Жалпысынан унаалар таза, айдоочулар сылык жана баалары жеткиликтүү.',
      date: '23.06.2024'
    }
  ];

  const renderStars = (rating: number) => {
    return Array(5).fill(0).map((_, i) => (
      <Star 
        key={i} 
        size={16} 
        className={i < rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"} 
      />
    ));
  };

  return (
    <section className="py-20 bg-gray-900 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Кардарлардын пикирлери</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            KyrgyzGo кызматын колдонгон кардарларыбыздын пикирлери менен таанышыңыз
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="bg-gray-800 rounded-xl p-6">
              <div className="flex items-center mb-4">
                <img 
                  src={testimonial.avatar} 
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover mr-4" 
                />
                <div>
                  <h4 className="font-medium">{testimonial.name}</h4>
                  <div className="flex mt-1">
                    {renderStars(testimonial.rating)}
                  </div>
                </div>
              </div>
              <p className="text-gray-300 mb-4">{testimonial.text}</p>
              <p className="text-sm text-gray-500">{testimonial.date}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <a 
            href="/reviews" 
            className="inline-block border border-red-500 text-red-500 hover:bg-red-500 hover:text-white px-8 py-3 rounded-full font-medium transition-colors"
          >
            Бардык пикирлерди көрүү
          </a>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;