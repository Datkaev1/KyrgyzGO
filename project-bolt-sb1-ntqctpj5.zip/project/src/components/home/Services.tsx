import React from 'react';
import { Car, Users, Shield, Clock, CreditCard, MapPin } from 'lucide-react';

const Services: React.FC = () => {
  const services = [
    {
      icon: <Car className="text-red-600" size={36} />,
      title: 'Бардык унаа түрлөрү',
      description: 'Эконом, комфорт, бизнес класс жана минивэн сыяктуу ар кандай муктаждыктарга ылайыктуу унаалар'
    },
    {
      icon: <Users className="text-red-600" size={36} />,
      title: 'Тажрыйбалуу айдоочулар',
      description: 'Жогорку квалификациялуу, тажрыйбалуу жана сылык айдоочулар сиздин коопсуз жүрүүңүздү камсыз кылышат'
    },
    {
      icon: <Shield className="text-red-600" size={36} />,
      title: 'Коопсуздук',
      description: 'Унаалардын техникалык абалы дайыма текшерилип, санитардык талаптар сакталат'
    },
    {
      icon: <Clock className="text-red-600" size={36} />,
      title: '24/7 тейлөө',
      description: 'Күнү-түнү биздин кызмат көрсөтүүлөрдөн пайдаланууга мүмкүнчүлүгүңүз бар'
    },
    {
      icon: <CreditCard className="text-red-600" size={36} />,
      title: 'Ыңгайлуу төлөө',
      description: 'Накталай акча же банктык карта менен төлөө мүмкүнчүлүгү'
    },
    {
      icon: <MapPin className="text-red-600" size={36} />,
      title: 'Так жеткирүү',
      description: 'Так жана ыкчам жеткирүү, унааңыз 5-10 мүнөттүн ичинде келет'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Биздин кызматтар</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            KyrgyzGo такси кызматы сиздин жүрүүңүздү ыңгайлуу жана коопсуз кылуу үчүн
            ар кандай кызматтарды сунуштайт
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="bg-white rounded-xl shadow-md p-6 transition-transform hover:-translate-y-1"
            >
              <div className="mb-4">{service.icon}</div>
              <h3 className="text-xl font-bold mb-3">{service.title}</h3>
              <p className="text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;