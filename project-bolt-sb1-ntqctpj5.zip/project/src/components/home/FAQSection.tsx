import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  
  const faqs = [
    {
      question: 'KyrgyzGo кызматын колдонуу үчүн кандай каттоодон өтүү керек?',
      answer: 'KyrgyzGo кызматын колдонуу үчүн мобилдик тиркемебизди же вебсайтыбызды ачып, телефон номериңизди киргизип, SMS аркылуу келген коддуу колдонуп катталсаңыз болот. Каттоодон өткөндөн кийин эле такси чакыра аласыз.'
    },
    {
      question: 'Такси тапшырмасын алдын ала берсе болобу?',
      answer: 'Ооба, KyrgyzGo кызматында сиз тапшырманы алдын ала берсеңиз болот. Бул үчүн тиркемеде же сайтта "Алдын ала заказ" бөлүмүн тандап, керектүү күн жана убакытты көрсөтүңүз. Биз белгиленген убакытта такси жөнөтөбүз.'
    },
    {
      question: 'Кайсы төлөм ыкмалары колдонулат?',
      answer: 'KyrgyzGo кызматында накталай акча менен да, банктык карта менен да төлөй аласыз. Тиркемеде же сайтта тапшырма берүү учурунда, сизге ыңгайлуу төлөм ыкмасын тандасаңыз болот.'
    },
    {
      question: 'Тапшырма берилгенден кийин канча убакытта такси келет?',
      answer: 'Көпчүлүк учурда такси 5-10 мүнөттүн ичинде келет. Бирок бул убакыт шаардагы жол кыймылынын жыштыгына, аба-ырайына жана башка шарттарга жараша өзгөрүшү мүмкүн. Сиз тапшырма берилгенден кийин айдоочунун жакындап келе жатканын тиркемеден көрө аласыз.'
    },
    {
      question: 'Башка шаарларда KyrgyzGo кызматы иштейби?',
      answer: 'Учурда KyrgyzGo кызматы Бишкек шаарында жана Чүй облусунда иштейт. Жакында башка чоң шаарларга да кызматыбызды кеңейтүүнү пландап жатабыз.'
    }
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Көп берилүүчү суроолор</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            KyrgyzGo кызматы тууралуу көп берилүүчү суроолор жана жооптор
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <div 
              key={index} 
              className="border-b border-gray-200 py-5"
            >
              <button
                className="flex justify-between items-center w-full text-left focus:outline-none"
                onClick={() => toggleFAQ(index)}
              >
                <h3 className="text-lg font-medium">{faq.question}</h3>
                {openIndex === index ? (
                  <ChevronUp className="text-red-600" size={20} />
                ) : (
                  <ChevronDown className="text-gray-600" size={20} />
                )}
              </button>
              <div 
                className={`mt-3 text-gray-600 transition-all duration-300 ${
                  openIndex === index ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0 overflow-hidden'
                }`}
              >
                <p>{faq.answer}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-gray-600 mb-4">Башка суроолоруңуз барбы?</p>
          <a 
            href="/contact" 
            className="inline-block bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-full font-medium transition-colors"
          >
            Биз менен байланышыңыз
          </a>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;