import React from 'react';
import { Smartphone, MapPin, Car } from 'lucide-react';

const HowItWorks: React.FC = () => {
  const steps = [
    {
      icon: <Smartphone className="text-red-600" size={48} />,
      title: '1. Тапшырма берүү',
      description: 'Мобилдик тиркеме же сайт аркылуу тапшырма бериңиз. Даректерди киргизип, унаа түрүн тандаңыз.'
    },
    {
      icon: <Car className="text-red-600" size={48} />,
      title: '2. Унаа тандоо',
      description: 'Өзүңүзгө ылайыктуу унаанын түрүн жана тарифти тандаңыз. Комфорт, эконом же бизнес класс.'
    },
    {
      icon: <MapPin className="text-red-600" size={48} />,
      title: '3. Жол тартуу',
      description: 'Унаа келгенден кийин жолго чыгып, максатка жеткенден кийин төлөмдү жүргүзүңүз.'
    }
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Кантип иштейт</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            KyrgyzGo менен такси чакыруу оңой жана ыңгайлуу. 
            Жөн гана бир нече жөнөкөй кадамдарды аткарыңыз.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="text-center">
              <div className="bg-red-50 w-24 h-24 mx-auto mb-6 rounded-full flex items-center justify-center transform transition-transform hover:scale-110">
                {step.icon}
              </div>
              <h3 className="text-xl font-bold mb-3">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <a 
            href="/book" 
            className="inline-block bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-full font-medium transition-colors"
          >
            Азыр эле такси чакыруу
          </a>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;