import React from 'react';
import { MapPin, Calendar, Clock } from 'lucide-react';
import BookingForm from '../booking/BookingForm';

const Hero: React.FC = () => {
  return (
    <div className="relative min-h-screen flex items-center">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.pexels.com/photos/7087268/pexels-photo-7087268.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
          alt="Bishkek City Taxi"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black opacity-50"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10 pt-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
              <span className="block">Кыргызстан боюнча</span>
              <span className="text-yellow-500">ишенимдүү такси</span>
              <span className="block">кызматы</span>
            </h1>
            
            <p className="text-lg md:text-xl mb-8 text-gray-200">
              Шаарда жүрүү жеңил жана ыңгайлуу. Ишенимдүү айдоочулар, 
              ыңгайлуу унаалар жана жеткиликтүү баалар менен.
            </p>
            
            <div className="flex flex-wrap gap-6 mb-12">
              <div className="flex items-center">
                <MapPin className="text-red-500 mr-2" size={24} />
                <span className="text-gray-200">Бишкек жана Чүй облусу</span>
              </div>
              <div className="flex items-center">
                <Clock className="text-red-500 mr-2" size={24} />
                <span className="text-gray-200">24/7 тейлөө</span>
              </div>
              <div className="flex items-center">
                <Calendar className="text-red-500 mr-2" size={24} />
                <span className="text-gray-200">Алдын ала заказ берүү</span>
              </div>
            </div>
          </div>
          
          <div>
            <BookingForm />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;