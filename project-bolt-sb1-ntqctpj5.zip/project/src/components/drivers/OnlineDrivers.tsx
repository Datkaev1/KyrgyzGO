import React, { useState, useEffect } from 'react';
import { YMaps, Map, Placemark } from '@pbe/react-yandex-maps';
import { Car } from 'lucide-react';

interface Driver {
  id: string;
  name: string;
  location: [number, number];
  vehicle: {
    type: string;
    model: string;
    number: string;
  };
  rating: number;
  isAvailable: boolean;
}

const OnlineDrivers: React.FC = () => {
  const [drivers, setDrivers] = useState<Driver[]>([
    {
      id: '1',
      name: 'Азамат К.',
      location: [42.8746, 74.5698],
      vehicle: {
        type: 'economy',
        model: 'Toyota Camry',
        number: 'B 1234 AB'
      },
      rating: 4.8,
      isAvailable: true
    },
    {
      id: '2',
      name: 'Бакыт М.',
      location: [42.8700, 74.5900],
      vehicle: {
        type: 'comfort',
        model: 'Honda Accord',
        number: 'B 5678 AB'
      },
      rating: 4.9,
      isAvailable: true
    },
    {
      id: '3',
      name: 'Чынгыз Т.',
      location: [42.8800, 74.5800],
      vehicle: {
        type: 'business',
        model: 'Mercedes E-Class',
        number: 'B 9012 AB'
      },
      rating: 5.0,
      isAvailable: true
    }
  ]);

  const [selectedDriver, setSelectedDriver] = useState<Driver | null>(null);
  const [mapCenter] = useState([42.8746, 74.5698]); // Bishkek coordinates

  useEffect(() => {
    // Simulate driver movement
    const interval = setInterval(() => {
      setDrivers(prevDrivers => 
        prevDrivers.map(driver => ({
          ...driver,
          location: [
            driver.location[0] + (Math.random() - 0.5) * 0.001,
            driver.location[1] + (Math.random() - 0.5) * 0.001
          ]
        }))
      );
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-white rounded-xl shadow-xl p-6">
      <h2 className="text-2xl font-bold mb-6">Онлайн айдоочулар</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <YMaps>
            <div className="h-[500px] rounded-lg overflow-hidden">
              <Map
                defaultState={{
                  center: mapCenter,
                  zoom: 13,
                }}
                width="100%"
                height="100%"
              >
                {drivers.map(driver => (
                  <Placemark
                    key={driver.id}
                    geometry={driver.location}
                    options={{
                      iconLayout: 'default#image',
                      iconImageHref: 'https://cdn-icons-png.flaticon.com/512/3097/3097144.png',
                      iconImageSize: [32, 32],
                    }}
                    onClick={() => setSelectedDriver(driver)}
                  />
                ))}
              </Map>
            </div>
          </YMaps>
        </div>
        
        <div className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-600">Онлайн айдоочулар:</span>
              <span className="font-bold text-green-600">{drivers.length}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Бош айдоочулар:</span>
              <span className="font-bold text-green-600">
                {drivers.filter(d => d.isAvailable).length}
              </span>
            </div>
          </div>

          {selectedDriver && (
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="flex items-center mb-4">
                <Car className="text-red-600 mr-3" size={24} />
                <div>
                  <h3 className="font-medium">{selectedDriver.name}</h3>
                  <div className="flex items-center text-sm text-gray-500">
                    <span className="mr-2">⭐ {selectedDriver.rating}</span>
                    <span>{selectedDriver.vehicle.type}</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Унаа:</span>
                  <span className="font-medium">{selectedDriver.vehicle.model}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Номери:</span>
                  <span className="font-medium">{selectedDriver.vehicle.number}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Статус:</span>
                  <span className="text-green-600 font-medium">
                    {selectedDriver.isAvailable ? 'Бош' : 'Бош эмес'}
                  </span>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-2">
            {drivers.map(driver => (
              <button
                key={driver.id}
                className={`w-full text-left p-3 rounded-lg transition-colors ${
                  selectedDriver?.id === driver.id
                    ? 'bg-red-50 border border-red-200'
                    : 'bg-gray-50 hover:bg-gray-100'
                }`}
                onClick={() => setSelectedDriver(driver)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">{driver.name}</div>
                    <div className="text-sm text-gray-500">{driver.vehicle.model}</div>
                  </div>
                  <div className="text-sm">
                    <div className="text-yellow-500">⭐ {driver.rating}</div>
                    <div className="text-green-600">{driver.isAvailable ? 'Бош' : 'Бош эмес'}</div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OnlineDrivers;