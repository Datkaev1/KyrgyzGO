import React from 'react';
import { Facebook, Instagram, Twitter, MapPin, Phone, Mail } from 'lucide-react';
import { Link } from '../common/Link';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-2xl font-bold mb-6 flex items-center">
              <span className="text-red-500">Kyrgyz</span>
              <span className="text-yellow-500">Go</span>
            </h3>
            <p className="text-gray-400 mb-6">
              Кыргызстандагы заманбап жана ишенимдүү такси кызматы. 
              Биз менен шаарда жүрүү ыңгайлуу жана коопсуз!
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook size={20} />
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram size={20} />
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter size={20} />
              </Link>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-6">Шилтемелер</h4>
            <ul className="space-y-3">
              <li>
                <Link href="/" className="text-gray-400 hover:text-white transition-colors">
                  Башкы бет
                </Link>
              </li>
              <li>
                <Link href="/book" className="text-gray-400 hover:text-white transition-colors">
                  Такси чакыруу
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-gray-400 hover:text-white transition-colors">
                  Кызматтар
                </Link>
              </li>
              <li>
                <Link href="/tariffs" className="text-gray-400 hover:text-white transition-colors">
                  Тарифтер
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-400 hover:text-white transition-colors">
                  Биз жөнүндө
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-6">Кызматтар</h4>
            <ul className="space-y-3">
              <li>
                <Link href="/services/economy" className="text-gray-400 hover:text-white transition-colors">
                  Эконом
                </Link>
              </li>
              <li>
                <Link href="/services/comfort" className="text-gray-400 hover:text-white transition-colors">
                  Комфорт
                </Link>
              </li>
              <li>
                <Link href="/services/business" className="text-gray-400 hover:text-white transition-colors">
                  Бизнес
                </Link>
              </li>
              <li>
                <Link href="/services/minivan" className="text-gray-400 hover:text-white transition-colors">
                  Минивэн
                </Link>
              </li>
              <li>
                <Link href="/services/delivery" className="text-gray-400 hover:text-white transition-colors">
                  Жеткирүү
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-6">Байланыш</h4>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin size={20} className="text-red-500 mr-3 mt-1" />
                <span className="text-gray-400">Бишкек ш., Чүй пр., 123</span>
              </li>
              <li className="flex items-center">
                <Phone size={20} className="text-red-500 mr-3" />
                <span className="text-gray-400">+996 312 123-456</span>
              </li>
              <li className="flex items-center">
                <Mail size={20} className="text-red-500 mr-3" />
                <span className="text-gray-400">info@kyrgyzgo.kg</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between">
          <p className="text-gray-500 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} KyrgyzGo. Бардык укуктар корголгон.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link href="/terms" className="text-gray-500 hover:text-white text-sm transition-colors">
              Колдонуу шарттары
            </Link>
            <Link href="/privacy" className="text-gray-500 hover:text-white text-sm transition-colors">
              Купуялык саясаты
            </Link>
            <Link href="/faq" className="text-gray-500 hover:text-white text-sm transition-colors">
              Көп берилүүчү суроолор
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;