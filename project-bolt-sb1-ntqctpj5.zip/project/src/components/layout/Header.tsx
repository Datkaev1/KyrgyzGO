import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, ChevronDown, Globe } from 'lucide-react';
import { Link } from '../common/Link';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [language, setLanguage] = useState('ky');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  
  const changeLanguage = (lang: string) => {
    setLanguage(lang);
  };

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white shadow-md py-2' 
          : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-bold flex items-center">
              <span className="text-red-600">Kyrgyz</span>
              <span className="text-yellow-500">Go</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/book" className="font-medium hover:text-red-600 transition-colors">
              Такси чакыруу
            </Link>
            <Link href="/services" className="font-medium hover:text-red-600 transition-colors">
              Кызматтар
            </Link>
            <Link href="/tariffs" className="font-medium hover:text-red-600 transition-colors">
              Тарифтер
            </Link>
            <Link href="/about" className="font-medium hover:text-red-600 transition-colors">
              Биз жөнүндө
            </Link>
          </nav>

          <div className="hidden md:flex items-center space-x-6">
            <div className="relative group">
              <button className="flex items-center space-x-1 font-medium">
                <Globe size={18} />
                <span>{language === 'ky' ? 'Кыргызча' : 'Русский'}</span>
                <ChevronDown size={16} />
              </button>
              <div className="absolute right-0 mt-2 w-40 bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300">
                <button 
                  onClick={() => changeLanguage('ky')}
                  className={`block w-full text-left px-4 py-2 hover:bg-gray-100 ${language === 'ky' ? 'text-red-600' : ''}`}
                >
                  Кыргызча
                </button>
                <button 
                  onClick={() => changeLanguage('ru')}
                  className={`block w-full text-left px-4 py-2 hover:bg-gray-100 ${language === 'ru' ? 'text-red-600' : ''}`}
                >
                  Русский
                </button>
              </div>
            </div>
            
            <Link href="tel:+996312123456" className="flex items-center space-x-2 font-medium text-red-600">
              <Phone size={18} />
              <span>+996 312 123-456</span>
            </Link>
            
            <Link 
              href="/book" 
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-full font-medium transition-colors"
            >
              Такси чакыруу
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden text-gray-800" onClick={toggleMenu}>
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className={`md:hidden ${isMenuOpen ? 'block' : 'hidden'}`}>
        <div className="container mx-auto px-4 py-4 bg-white">
          <nav className="flex flex-col space-y-4">
            <Link href="/book" className="font-medium py-2 hover:text-red-600 transition-colors">
              Такси чакыруу
            </Link>
            <Link href="/services" className="font-medium py-2 hover:text-red-600 transition-colors">
              Кызматтар
            </Link>
            <Link href="/tariffs" className="font-medium py-2 hover:text-red-600 transition-colors">
              Тарифтер
            </Link>
            <Link href="/about" className="font-medium py-2 hover:text-red-600 transition-colors">
              Биз жөнүндө
            </Link>
            
            <div className="border-t border-gray-200 pt-4 mt-2 flex flex-col space-y-4">
              <div className="flex flex-col space-y-2">
                <span className="text-sm text-gray-500">Тилди тандаңыз</span>
                <div className="flex space-x-4">
                  <button 
                    onClick={() => changeLanguage('ky')} 
                    className={`py-1 px-3 rounded ${language === 'ky' ? 'bg-red-600 text-white' : 'bg-gray-100'}`}
                  >
                    Кыргызча
                  </button>
                  <button 
                    onClick={() => changeLanguage('ru')} 
                    className={`py-1 px-3 rounded ${language === 'ru' ? 'bg-red-600 text-white' : 'bg-gray-100'}`}
                  >
                    Русский
                  </button>
                </div>
              </div>
              
              <Link href="tel:+996312123456" className="flex items-center space-x-2 font-medium text-red-600">
                <Phone size={18} />
                <span>+996 312 123-456</span>
              </Link>
              
              <Link 
                href="/book" 
                className="bg-red-600 hover:bg-red-700 text-white py-3 rounded-full font-medium text-center transition-colors"
              >
                Такси чакыруу
              </Link>
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;