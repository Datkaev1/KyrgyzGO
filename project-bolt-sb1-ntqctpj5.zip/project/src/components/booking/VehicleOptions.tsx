import React from 'react';
import { VehicleType } from '../../types';

interface VehicleOptionsProps {
  selected: VehicleType;
  onSelect: (vehicleType: VehicleType) => void;
}

const VehicleOptions: React.FC<VehicleOptionsProps> = ({ selected, onSelect }) => {
  const vehicles = [
    {
      id: 'economy',
      name: 'Эконом',
      description: 'Жеткиликтүү баа',
      image: '/economy-car.png',
      price: 'от 150 сом'
    },
    {
      id: 'comfort',
      name: 'Комфорт',
      description: 'Ыңгайлуу унаа',
      image: '/comfort-car.png',
      price: 'от 200 сом'
    },
    {
      id: 'business',
      name: 'Бизнес',
      description: 'Премиум класс',
      image: '/business-car.png',
      price: 'от 350 сом'
    },
    {
      id: 'minivan',
      name: 'Минивэн',
      description: '4+ жүргүнчү',
      image: '/minivan-car.png',
      price: 'от 400 сом'
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {vehicles.map((vehicle) => (
        <div
          key={vehicle.id}
          className={`cursor-pointer border rounded-lg p-3 transition-all ${
            selected === vehicle.id
              ? 'border-red-500 bg-red-50'
              : 'border-gray-200 hover:border-gray-300'
          }`}
          onClick={() => onSelect(vehicle.id as VehicleType)}
        >
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 mb-2 flex items-center justify-center">
              {/* Placeholder for vehicle icon */}
              <div className="w-full h-full bg-gray-200 rounded-full flex items-center justify-center">
                {vehicle.name.charAt(0)}
              </div>
            </div>
            <h4 className="font-medium text-sm">{vehicle.name}</h4>
            <p className="text-xs text-gray-500 mt-1">{vehicle.price}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default VehicleOptions;