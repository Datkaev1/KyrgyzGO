import React, { useState } from 'react';
import { MapPin, Calendar, Clock, Navigation, CreditCard, Smartphone } from 'lucide-react';
import { YMaps, Map, Placemark } from '@pbe/react-yandex-maps';
import VehicleOptions from './VehicleOptions';
import { VehicleType } from '../../types';

const BookingForm: React.FC = () => {
  const [selectedTab, setSelectedTab] = useState<'now' | 'schedule'>('now');
  const [pickup, setPickup] = useState('');
  const [destination, setDestination] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleType>('economy');
  const [estimatedPrice, setEstimatedPrice] = useState<number | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'sbp'>('cash');
  const [mapCenter] = useState([42.8746, 74.5698]); // Bishkek coordinates
  
  const handleAddressChange = () => {
    const basePrices = {
      economy: 150,
      comfort: 200,
      business: 350,
      minivan: 400
    };
    
    if (pickup && destination) {
      const basePrice = basePrices[selectedVehicle];
      const randomFactor = Math.floor(Math.random() * 100) + 50;
      setEstimatedPrice(basePrice + randomFactor);
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log({
      pickup,
      destination,
      date: selectedTab === 'schedule' ? date : new Date().toISOString().split('T')[0],
      time: selectedTab === 'schedule' ? time : new Date().toTimeString().split(' ')[0].slice(0, 5),
      vehicleType: selectedVehicle,
      estimatedPrice,
      paymentMethod
    });
    
    if (paymentMethod === 'sbp') {
      // In a real app, this would generate a QR code for SBP payment
      alert('СБП QR-код жаратылды. Төлөм үчүн банк тиркемеңизди колдонуңуз.');
    } else {
      alert('Такси заказы ийгиликтүү жөнөтүлдү!');
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-xl p-6 md:p-8">
      <div className="flex border-b border-gray-200 mb-6">
        <button
          className={`pb-3 px-4 text-sm font-medium ${
            selectedTab === 'now'
              ? 'border-b-2 border-red-600 text-red-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
          onClick={() => setSelectedTab('now')}
        >
          Азыр
        </button>
        <button
          className={`pb-3 px-4 text-sm font-medium ${
            selectedTab === 'schedule'
              ? 'border-b-2 border-red-600 text-red-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
          onClick={() => setSelectedTab('schedule')}
        >
          Алдын ала заказ
        </button>
      </div>

      <YMaps>
        <div className="mb-6 h-64 rounded-lg overflow-hidden">
          <Map
            defaultState={{
              center: mapCenter,
              zoom: 12,
            }}
            width="100%"
            height="100%"
          >
            <Placemark geometry={mapCenter} />
          </Map>
        </div>
      </YMaps>

      <form onSubmit={handleSubmit}>
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-medium mb-2">Кайдан</label>
          <div className="relative">
            <MapPin className="absolute left-3 top-3 text-gray-400" size={20} />
            <input
              type="text"
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              placeholder="Алуу дареги"
              value={pickup}
              onChange={(e) => {
                setPickup(e.target.value);
                handleAddressChange();
              }}
              required
            />
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-medium mb-2">Кайда</label>
          <div className="relative">
            <Navigation className="absolute left-3 top-3 text-gray-400" size={20} />
            <input
              type="text"
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              placeholder="Баруу дареги"
              value={destination}
              onChange={(e) => {
                setDestination(e.target.value);
                handleAddressChange();
              }}
              required
            />
          </div>
        </div>

        {selectedTab === 'schedule' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <label className="block text-gray-700 text-sm font-medium mb-2">Күнү</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-3 text-gray-400" size={20} />
                <input
                  type="date"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required={selectedTab === 'schedule'}
                />
              </div>
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-medium mb-2">Убакыт</label>
              <div className="relative">
                <Clock className="absolute left-3 top-3 text-gray-400" size={20} />
                <input
                  type="time"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  required={selectedTab === 'schedule'}
                />
              </div>
            </div>
          </div>
        )}

        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-medium mb-2">Унаа түрү</label>
          <VehicleOptions selected={selectedVehicle} onSelect={setSelectedVehicle} />
        </div>

        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-medium mb-2">Төлөө ыкмасы</label>
          <div className="grid grid-cols-2 gap-4">
            <button
              type="button"
              className={`flex items-center border rounded-lg p-3 transition-colors ${
                paymentMethod === 'cash'
                  ? 'border-red-500 bg-red-50'
                  : 'border-gray-300 hover:border-gray-400'
              }`}
              onClick={() => setPaymentMethod('cash')}
            >
              <CreditCard className={`mr-3 ${paymentMethod === 'cash' ? 'text-red-500' : 'text-gray-400'}`} size={20} />
              <span className={paymentMethod === 'cash' ? 'text-red-700' : 'text-gray-700'}>Накталай акча</span>
            </button>
            <button
              type="button"
              className={`flex items-center border rounded-lg p-3 transition-colors ${
                paymentMethod === 'sbp'
                  ? 'border-red-500 bg-red-50'
                  : 'border-gray-300 hover:border-gray-400'
              }`}
              onClick={() => setPaymentMethod('sbp')}
            >
              <Smartphone className={`mr-3 ${paymentMethod === 'sbp' ? 'text-red-500' : 'text-gray-400'}`} size={20} />
              <span className={paymentMethod === 'sbp' ? 'text-red-700' : 'text-gray-700'}>СБП</span>
            </button>
          </div>
        </div>

        {estimatedPrice && (
          <div className="mb-6 p-4 bg-gray-50 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="text-gray-700 font-medium">Болжолдуу баасы:</span>
              <span className="text-xl font-bold text-red-600">{estimatedPrice} сом</span>
            </div>
          </div>
        )}

        <button
          type="submit"
          className="w-full bg-red-600 hover:bg-red-700 text-white py-3 rounded-lg font-medium transition-colors duration-300"
        >
          {selectedTab === 'now' ? 'Такси чакыруу' : 'Заказ берүү'}
        </button>
      </form>
    </div>
  );
};

export default BookingForm;